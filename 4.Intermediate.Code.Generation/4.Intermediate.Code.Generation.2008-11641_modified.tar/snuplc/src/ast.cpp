//------------------------------------------------------------------------------
/// @brief SnuPL abstract syntax tree
/// @author Bernhard Egger <bernhard@csap.snu.ac.kr>
/// @section changelog Change Log
/// 2012/09/14 Bernhard Egger created
/// 2013/03/07 Bernhard Egger adapted to SnuPL/0
/// 2014/09/28 Bernhard Egger assignment 2: AST for SnuPL/-1
///
/// @section license_section License
/// Copyright (c) 2012-2014, Bernhard Egger
/// All rights reserved.
///
/// Redistribution and use in source and binary forms,  with or without modifi-
/// cation, are permitted provided that the following conditions are met:
///
/// - Redistributions of source code must retain the above copyright notice,
///   this list of conditions and the following disclaimer.
/// - Redistributions in binary form must reproduce the above copyright notice,
///   this list of conditions and the following disclaimer in the documentation
///   and/or other materials provided with the distribution.
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
/// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,  BUT NOT LIMITED TO,  THE
/// IMPLIED WARRANTIES OF MERCHANTABILITY  AND FITNESS FOR A PARTICULAR PURPOSE
/// ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT HOLDER  OR CONTRIBUTORS BE
/// LIABLE FOR ANY DIRECT,  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSE-
/// QUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF  SUBSTITUTE
/// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT
/// LIABILITY, OR TORT  (INCLUDING NEGLIGENCE OR OTHERWISE)  ARISING IN ANY WAY
/// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
/// DAMAGE.
//------------------------------------------------------------------------------

#include <iostream>
#include <cassert>

#include <typeinfo>

#include "ast.h"
using namespace std;


//------------------------------------------------------------------------------
// CAstNode
//
int CAstNode::_global_id = 0;

CAstNode::CAstNode(CToken token)
  : _token(token), _addr(NULL)
{
  _id = _global_id++;
}

CAstNode::~CAstNode(void)
{
  if (_addr != NULL) delete _addr;
}

int CAstNode::GetID(void) const
{
  return _id;
}

CToken CAstNode::GetToken(void) const
{
  return _token;
}

const CType* CAstNode::GetType(void) const
{
  return CTypeManager::Get()->GetNull();
}

string CAstNode::dotID(void) const
{
  ostringstream out;
  out << "node" << dec << _id;
  return out.str();
}

string CAstNode::dotAttr(void) const
{
  return " [label=\"" + dotID() + "\"]";
}

void CAstNode::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << dotID() << dotAttr() << ";" << endl;
}

CTacAddr* CAstNode::ToTac(CCodeBlock *cb)
{
  return NULL;
}

CTacAddr* CAstNode::GetTacAddr(void) const
{
  return NULL;
}

ostream& operator<<(ostream &out, const CAstNode &t)
{
  return t.print(out);
}

ostream& operator<<(ostream &out, const CAstNode *t)
{
  return t->print(out);
}

//------------------------------------------------------------------------------
// CAstScope
//
CAstScope::CAstScope(CToken t, const string name, CAstScope *parent)
  : CAstNode(t), _name(name), _symtab(NULL), _parent(parent), _statseq(NULL),
    _cb(NULL)
{
  if (_parent != NULL) _parent->AddChild(this);
}

CAstScope::~CAstScope(void)
{
  delete _symtab;
  delete _statseq;
  delete _cb;
}

const string CAstScope::GetName(void) const
{
  return _name;
}

CAstScope* CAstScope::GetParent(void) const
{
  return _parent;
}

size_t CAstScope::GetNumChildren(void) const
{
  return _children.size();
}

CAstScope* CAstScope::GetChild(size_t i) const
{
  assert(i < _children.size());
  return _children[i];
}

CSymtab* CAstScope::GetSymbolTable(void) const
{
  assert(_symtab != NULL);
  return _symtab;
}

void CAstScope::SetStatementSequence(CAstStatement *statseq)
{
  _statseq = statseq;
}

CAstStatement* CAstScope::GetStatementSequence(void) const
{
  return _statseq;
}

bool CAstScope::TypeCheck(CToken *t, string *msg) const
{
    bool result = true;

    try {
        CAstStatement *s = _statseq;
        while (result && (s != NULL)) {
            result = s->TypeCheck(t,msg);
            s = s->GetNext();
        }

        vector<CAstScope*>::const_iterator it = _children.begin();
        while (result && (it != _children.end())) {
            result = (*it)->TypeCheck(t, msg);
            it++;
        }
    }
    catch (...) {
        result = false;
    }

    return result;
}

ostream& CAstScope::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "CAstScope: '" << _name << "'" << endl;
  out << ind << "  symbol table:" << endl;
  _symtab->print(out, indent+4);
  out << ind << "  statement list:" << endl;
  CAstStatement *s = GetStatementSequence();
  if (s != NULL) {
    do {
      s->print(out, indent+4);
      s = s->GetNext();
    } while (s != NULL);
  } else {
    out << ind << "    empty." << endl;
  }

  out << ind << "  nested scopes:" << endl;
  if (_children.size() > 0) {
    for (size_t i=0; i<_children.size(); i++) {
      _children[i]->print(out, indent+4);
    }
  } else {
    out << ind << "    empty." << endl;
  }
  out << ind << endl;

  return out;
}

void CAstScope::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  CAstStatement *s = GetStatementSequence();
  if (s != NULL) {
    string prev = dotID();
    do {
      s->toDot(out, indent);
      out << ind << prev << " -> " << s->dotID() << " [style=dotted];" << endl;
      prev = s->dotID();
      s = s->GetNext();
    } while (s != NULL);
  }

  vector<CAstScope*>::const_iterator it = _children.begin();
  while (it != _children.end()) {
    CAstScope *s = *it++;
    s->toDot(out, indent);
    out << ind << dotID() << " -> " << s->dotID() << ";" << endl;
  }

}

CTacAddr* CAstScope::ToTac(CCodeBlock *cb)
{
    assert(cb != NULL);

    CAstStatement *s = GetStatementSequence();
    while (s != NULL)
    {
        CTacLabel *next = cb->CreateLabel();
        s->ToTac(cb, next);
        cb->AddInstr(next);
        s = s->GetNext();
    }

    //[fix-me]
    cb->CleanupControlFlow();

    return NULL;
}

CCodeBlock* CAstScope::GetCodeBlock(void) const
{
  return _cb;
}

void CAstScope::SetSymbolTable(CSymtab *st)
{
  if (_symtab != NULL) delete _symtab;
  _symtab = st;
}

void CAstScope::AddChild(CAstScope *child)
{
  _children.push_back(child);
}


//------------------------------------------------------------------------------
// CAstModule
//
CAstModule::CAstModule(CToken t, const string name)
  : CAstScope(t, name, NULL)
{
  SetSymbolTable(new CSymtab());
}

CSymbol* CAstModule::CreateVar(const string ident, const CType *type)
{
  return new CSymGlobal(ident, type);
}

string CAstModule::dotAttr(void) const
{
  return " [label=\"m " + GetName() + "\",shape=box]";
}



//------------------------------------------------------------------------------
// CAstProcedure
//
CAstProcedure::CAstProcedure(CToken t, const string name,
                             CAstScope *parent, CSymProc *symbol)
  : CAstScope(t, name, parent), _symbol(symbol)
{
  assert(GetParent() != NULL);
  SetSymbolTable(new CSymtab(GetParent()->GetSymbolTable()));
  assert(_symbol != NULL);
}

CSymProc* CAstProcedure::GetSymbol(void) const
{
  return _symbol;
}

CSymbol* CAstProcedure::CreateVar(const string ident, const CType *type)
{
  return new CSymLocal(ident, type);
}

const CType* CAstProcedure::GetType(void) const
{
  return GetSymbol()->GetDataType();
}

string CAstProcedure::dotAttr(void) const
{
  return " [label=\"p/f " + GetName() + "\",shape=box]";
}


//------------------------------------------------------------------------------
// CAstType
//
CAstType::CAstType(CToken t, const CType *type)
  : CAstNode(t), _type(type)
{
  assert(type != NULL);
}

const CType* CAstType::GetType(void) const
{
  return _type;
}

ostream& CAstType::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "CAstType (" << _type << ")" << endl;
  return out;
}


//------------------------------------------------------------------------------
// CAstStatement
//
CAstStatement::CAstStatement(CToken token)
  : CAstNode(token), _next(NULL)
{
}

CAstStatement::~CAstStatement(void)
{
  delete _next;
}

void CAstStatement::SetNext(CAstStatement *next)
{
  _next = next;
}

CAstStatement* CAstStatement::GetNext(void) const
{
  return _next;
}

//CTacAddr* CAstStatement::ToTac(CCodeBlock *cb)
//{
//    return NULL;
//}

CTacAddr* CAstStatement::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    // generate code for the statement
    cb->AddInstr(new CTacInstr(opGoto, next));
    return NULL;
}


//------------------------------------------------------------------------------
// CAstStatAssign
//
CAstStatAssign::CAstStatAssign(CToken t,
                               CAstDesignator *lhs, CAstExpression *rhs)
  : CAstStatement(t), _lhs(lhs), _rhs(rhs)
{
  assert(lhs != NULL);
  assert(rhs != NULL);
}

CAstDesignator* CAstStatAssign::GetLHS(void) const
{
  return _lhs;
}

CAstExpression* CAstStatAssign::GetRHS(void) const
{
  return _rhs;
}

bool CAstStatAssign::TypeCheck(CToken *t, string *msg) const
{
    CAstExpression* rhs = GetRHS();
    if (!rhs->TypeCheck(t,msg)) return false;
    
    CAstDesignator* lhs = GetLHS();
    if (!lhs->TypeCheck(t,msg)) return false;
   
    if (!lhs->GetType()->Match(rhs->GetType()))
    {
        if (t != NULL) *t = rhs->GetToken();
        if (msg != NULL) *msg = "assign : lhs&rhs types are not matched.";
        return false;
    }
    
    return true;
}

const CType* CAstStatAssign::GetType(void) const
{
  return _lhs->GetType();
}

ostream& CAstStatAssign::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << ":=" << " ";

  out << endl;

  _lhs->print(out, indent+2);
  _rhs->print(out, indent+2);

  return out;
}

string CAstStatAssign::dotAttr(void) const
{
  return " [label=\":=\",shape=box]";
}

void CAstStatAssign::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  _lhs->toDot(out, indent);
  out << ind << dotID() << "->" << _lhs->dotID() << ";" << endl;
  _rhs->toDot(out, indent);
  out << ind << dotID() << "->" << _rhs->dotID() << ";" << endl;
}

//CTacAddr* CAstStatAssign::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstStatAssign::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    // generate code for the statement
    CTacAddr* lhs_addr = _lhs->ToTac(cb, NULL, NULL);
    CTacAddr* rhs_addr = _rhs->ToTac(cb, NULL, NULL);
    cb->AddInstr(new CTacInstr(opAssign, lhs_addr, rhs_addr));
    cb->AddInstr(new CTacInstr(opGoto, next));
    return lhs_addr;
}


//------------------------------------------------------------------------------
// CAstStatCall
//
CAstStatCall::CAstStatCall(CToken t, CAstFunctionCall *call)
  : CAstStatement(t), _call(call)
{
  assert(call != NULL);
}

CAstFunctionCall* CAstStatCall::GetCall(void) const
{
  return _call;
}

bool CAstStatCall::TypeCheck(CToken *t, string *msg) const
{
  return GetCall()->TypeCheck(t, msg);
}

ostream& CAstStatCall::print(ostream &out, int indent) const
{
  _call->print(out, indent);

  return out;
}

string CAstStatCall::dotID(void) const
{
  return _call->dotID();
}

string CAstStatCall::dotAttr(void) const
{
  return _call->dotAttr();
}

void CAstStatCall::toDot(ostream &out, int indent) const
{
  _call->toDot(out, indent);
}

//CTacAddr* CAstStatCall::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstStatCall::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    // generate code for the statement
    CTacAddr* call_addr = _call->ToTac(cb, NULL, NULL);
    cb->AddInstr(new CTacInstr(opGoto, next));
    return call_addr;
}


//------------------------------------------------------------------------------
// CAstStatReturn
//
CAstStatReturn::CAstStatReturn(CToken t, CAstScope *scope, CAstExpression *expr)
  : CAstStatement(t), _scope(scope), _expr(expr)
{
  assert(scope != NULL);
}

CAstScope* CAstStatReturn::GetScope(void) const
{
  return _scope;
}

CAstExpression* CAstStatReturn::GetExpression(void) const
{
  return _expr;
}

bool CAstStatReturn::TypeCheck(CToken *t, string *msg) const
{
    const CType *st = GetScope()->GetType();
    CAstExpression *e = GetExpression();
    if (st->Match(CTypeManager::Get()->GetNull())) {
        if (e != NULL) {
            if (t != NULL) *t = e->GetToken();
            if (msg != NULL) *msg = "superfluous expression after return.";
            return false;
        }
    } else {
        if (e == NULL) {
            if (t != NULL) *t = GetToken();
            if (msg != NULL) *msg = "expression expected after return.";
            return false;
        }
        if (!e->TypeCheck(t, msg)) return false;
        if (!st->Match(e->GetType())) {
            if (t != NULL) *t = e->GetToken();
            if (msg != NULL) *msg = "return type mismatch.";
            return false;
        }
    }
    return true;
}

const CType* CAstStatReturn::GetType(void) const
{
  const CType *t = NULL;

  if (GetExpression() != NULL) {
    t = GetExpression()->GetType();
  } else {
    t = CTypeManager::Get()->GetNull();
  }

  return t;
}

ostream& CAstStatReturn::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "return" << " ";

  out << endl;

  if (_expr != NULL) _expr->print(out, indent+2);

  return out;
}

string CAstStatReturn::dotAttr(void) const
{
  return " [label=\"return\",shape=box]";
}

void CAstStatReturn::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  if (_expr != NULL) {
    _expr->toDot(out, indent);
    out << ind << dotID() << "->" << _expr->dotID() << ";" << endl;
  }
}

//CTacAddr* CAstStatReturn::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstStatReturn::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    // generate code for the statement
    if (NULL != _expr)
    {
        CTacAddr* expr_addr = _expr->ToTac(cb, NULL, NULL);
        cb->AddInstr(new CTacInstr(opReturn, NULL, expr_addr));
    }
    else
        cb->AddInstr(new CTacInstr(opReturn, NULL, NULL));
    cb->AddInstr(new CTacInstr(opGoto, next));
    return NULL;
}


//------------------------------------------------------------------------------
// CAstStatIf
//
CAstStatIf::CAstStatIf(CToken t, CAstExpression *cond,
                       CAstStatement *ifBody, CAstStatement *elseBody)
  : CAstStatement(t), _cond(cond), _ifBody(ifBody), _elseBody(elseBody)
{
  assert(cond != NULL);
}

CAstExpression* CAstStatIf::GetCondition(void) const
{
  return _cond;
}

CAstStatement* CAstStatIf::GetIfBody(void) const
{
  return _ifBody;
}

CAstStatement* CAstStatIf::GetElseBody(void) const
{
  return _elseBody;
}

bool CAstStatIf::TypeCheck(CToken *t, string *msg) const
{
    CAstExpression* cond = GetCondition();
    if(!cond->TypeCheck(t, msg)) return false;

    if(!cond->GetType()->Match(CTypeManager::Get()->GetBool()))
    {
        if (t != NULL) *t = cond->GetToken();
        if (msg != NULL) *msg = "if condition is not boolean type.";
        return false;
    }

    CAstStatement* ifbody = GetIfBody();
    while (ifbody != NULL)
    {
        if(!ifbody->TypeCheck(t, msg)) return false;
        ifbody = ifbody->GetNext();
    }
    CAstStatement* elsebody = GetElseBody();
    while (elsebody != NULL)
    {
        if(!elsebody->TypeCheck(t,msg)) return false;
        elsebody = elsebody->GetNext();
    }

    return true;
}

ostream& CAstStatIf::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "if cond" << endl;
  _cond->print(out, indent+2);
  out << ind << "if-body" << endl;
  if (_ifBody != NULL) {
    CAstStatement *s = _ifBody;
    do {
      s->print(out, indent+2);
      s = s->GetNext();
    } while (s != NULL);
  } else out << ind << "  empty." << endl;
  out << ind << "else-body" << endl;
  if (_elseBody != NULL) {
    CAstStatement *s = _elseBody;
    do {
      s->print(out, indent+2);
      s = s->GetNext();
    } while (s != NULL);
  } else out << ind << "  empty." << endl;

  return out;
}

string CAstStatIf::dotAttr(void) const
{
  return " [label=\"if\",shape=box]";
}

void CAstStatIf::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  _cond->toDot(out, indent);
  out << ind << dotID() << "->" << _cond->dotID() << ";" << endl;

  if (_ifBody != NULL) {
    CAstStatement *s = _ifBody;
    if (s != NULL) {
      string prev = dotID();
      do {
        s->toDot(out, indent);
        out << ind << prev << " -> " << s->dotID() << " [style=dotted];"
            << endl;
        prev = s->dotID();
        s = s->GetNext();
      } while (s != NULL);
    }
  }

  if (_elseBody != NULL) {
    CAstStatement *s = _elseBody;
    if (s != NULL) {
      string prev = dotID();
      do {
        s->toDot(out, indent);
        out << ind << prev << " -> " << s->dotID() << " [style=dotted];" 
            << endl;
        prev = s->dotID();
        s = s->GetNext();
      } while (s != NULL);
    }
  }
}

//CTacAddr* CAstStatIf::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstStatIf::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    // generate code for the statement
    CTacLabel* iftrue = cb->CreateLabel("if_true");
    CTacLabel* iffalse = cb->CreateLabel("if_false");
    _cond->ToTac(cb, iftrue, iffalse);

    cb->AddInstr(iftrue);
    CAstStatement *ifstats = _ifBody;
    while (ifstats != NULL)
    {
        CTacLabel *ifnext = cb->CreateLabel();
        ifstats->ToTac(cb, ifnext);
        cb->AddInstr(ifnext);
        ifstats = ifstats->GetNext();
    }
    cb->AddInstr(new CTacInstr(opGoto, next));
    cb->AddInstr(iffalse);
    CAstStatement *elsestats = _elseBody;
    while (elsestats != NULL)
    {
        CTacLabel *elsenext = cb->CreateLabel();
        elsestats->ToTac(cb, elsenext);
        cb->AddInstr(elsenext);
        elsestats = elsestats->GetNext();
    }
    cb->AddInstr(new CTacInstr(opGoto, next));
    return NULL;
}


//------------------------------------------------------------------------------
// CAstStatWhile
//
CAstStatWhile::CAstStatWhile(CToken t,
                             CAstExpression *cond, CAstStatement *body)
  : CAstStatement(t), _cond(cond), _body(body)
{
  assert(cond != NULL);
}

CAstExpression* CAstStatWhile::GetCondition(void) const
{
  return _cond;
}

CAstStatement* CAstStatWhile::GetBody(void) const
{
  return _body;
}

bool CAstStatWhile::TypeCheck(CToken *t, string *msg) const
{
    CAstExpression* cond = GetCondition();
    if(!cond->TypeCheck(t, msg)) return false;

    if(!cond->GetType()->Match(CTypeManager::Get()->GetBool()))
    {
        if (t != NULL) *t = cond->GetToken();
        if (msg != NULL) *msg = "while condition is not boolean type.";
        return false;
    }

    CAstStatement* body = GetBody();
    while (body != NULL)
    {
        if(!body->TypeCheck(t, msg)) return false;
        body = body->GetNext();
    }
    return true;
}

ostream& CAstStatWhile::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "while cond" << endl;
  _cond->print(out, indent+2);
  out << ind << "while-body" << endl;
  if (_body != NULL) {
    CAstStatement *s = _body;
    do {
      s->print(out, indent+2);
      s = s->GetNext();
    } while (s != NULL);
  }
  else out << ind << "  empty." << endl;

  return out;
}

string CAstStatWhile::dotAttr(void) const
{
  return " [label=\"while\",shape=box]";
}

void CAstStatWhile::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  _cond->toDot(out, indent);
  out << ind << dotID() << "->" << _cond->dotID() << ";" << endl;

  if (_body != NULL) {
    CAstStatement *s = _body;
    if (s != NULL) {
      string prev = dotID();
      do {
        s->toDot(out, indent);
        out << ind << prev << " -> " << s->dotID() << " [style=dotted];"
            << endl;
        prev = s->dotID();
        s = s->GetNext();
      } while (s != NULL);
    }
  }
}

//CTacAddr* CAstStatWhile::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstStatWhile::ToTac(CCodeBlock *cb, CTacLabel *next)
{
    CTacLabel* whilecond = cb->CreateLabel("while_cond");
    CTacLabel* whilebody = cb->CreateLabel("while_body");
    cb->AddInstr(whilecond);
    _cond->ToTac(cb, whilebody, next);

    cb->AddInstr(whilebody);
    CAstStatement *s = _body;
    while (s != NULL)
    {
        CTacLabel *bodynext = cb->CreateLabel();
        s->ToTac(cb, bodynext);
        cb->AddInstr(bodynext);
        s = s->GetNext();
    }
    cb->AddInstr(new CTacInstr(opGoto, whilecond));
    
    cb->AddInstr(new CTacInstr(opGoto, next));
    return NULL;
}


//------------------------------------------------------------------------------
// CAstExpression
//
CAstExpression::CAstExpression(CToken t)
  : CAstNode(t)
{
}


//------------------------------------------------------------------------------
// CAstOperation
//
CAstOperation::CAstOperation(CToken t, EOperation oper)
  : CAstExpression(t), _oper(oper)
{
}

EOperation CAstOperation::GetOperation(void) const
{
  return _oper;
}


//------------------------------------------------------------------------------
// CAstBinaryOp
//
CAstBinaryOp::CAstBinaryOp(CToken t, EOperation oper,
                           CAstExpression *l,CAstExpression *r)
  : CAstOperation(t, oper), _left(l), _right(r)
{
  // these are the only binary operation we support for now
  assert((oper == opAdd)        || (oper == opSub)         ||
         (oper == opMul)        || (oper == opDiv)         ||
         (oper == opAnd)        || (oper == opOr)          ||
         (oper == opEqual)      || (oper == opNotEqual)    ||
         (oper == opLessThan)   || (oper == opLessEqual)   ||
         (oper == opBiggerThan) || (oper == opBiggerEqual)
        );
  assert(l != NULL);
  assert(r != NULL);
}

CAstExpression* CAstBinaryOp::GetLeft(void) const
{
  return _left;
}

CAstExpression* CAstBinaryOp::GetRight(void) const
{
  return _right;
}

bool CAstBinaryOp::TypeCheck(CToken *t, string *msg) const
{
    CAstExpression* left = GetLeft();
    CAstExpression* right = GetRight();
    EOperation oper = GetOperation();
    if(!left->TypeCheck(t,msg)) return false;
    if(!right->TypeCheck(t,msg)) return false;
    int nType = 0;
    if ((oper == opAdd) || (oper == opSub) || (oper == opMul) || (oper == opDiv)
        || (oper == opLessThan) || (oper == opLessEqual) 
        || (oper == opBiggerThan) || (oper == opBiggerEqual)      
       )
    {
        if(!left->GetType()->Match(CTypeManager::Get()->GetInt())) 
            nType = 1;
        else if(!right->GetType()->Match(CTypeManager::Get()->GetInt()))
            nType = 2;
    }
    else if ((oper == opAnd) || (oper == opOr))
    {
        if(!left->GetType()->Match(CTypeManager::Get()->GetBool()))
            nType = 1;
        else if(!right->GetType()->Match(CTypeManager::Get()->GetBool()))
            nType = 2;
    }
    else if ((oper == opEqual) || (oper == opNotEqual))
    {
        if(left->GetType()->Match(CTypeManager::Get()->GetNull()))
            nType = 1;
        else if(right->GetType()->Match(CTypeManager::Get()->GetNull()))
            nType = 2;
    }

    if(nType > 0)
    {
        if(nType == 1)
        {
            if(t != NULL) *t = left->GetToken();
            if(msg != NULL) *msg = "binary operator lhs is not correct type";
        }
        else if(nType == 2)
        {
            if(t != NULL) *t = right->GetToken();
            if(msg != NULL) *msg = "binary operator rhs is not correct type";
        }
        return false;
    }
    return true;
}

const CType* CAstBinaryOp::GetType(void) const
{
    EOperation oper = GetOperation();
    if ((oper == opAdd)
        || (oper == opSub)
        || (oper == opMul)
        || (oper == opDiv)
       )
        return CTypeManager::Get()->GetInt();
    else
        return CTypeManager::Get()->GetBool();
}

ostream& CAstBinaryOp::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << GetOperation() << " ";

  out << endl;

  _left->print(out, indent+2);
  _right->print(out, indent+2);

  return out;
}

string CAstBinaryOp::dotAttr(void) const
{
  ostringstream out;
  out << " [label=\"" << GetOperation() << "\",shape=box]";
  return out.str();
}

void CAstBinaryOp::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  _left->toDot(out, indent);
  out << ind << dotID() << "->" << _left->dotID() << ";" << endl;
  _right->toDot(out, indent);
  out << ind << dotID() << "->" << _right->dotID() << ";" << endl;
}

//CTacAddr* CAstBinaryOp::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstBinaryOp::ToTac(CCodeBlock *cb, CTacLabel *ltrue, CTacLabel *lfalse)
{
    // generate jumping code for boolean expression
    EOperation oper = GetOperation();
    CTacTemp* t = NULL;
    if (oper == opAnd || oper == opOr || IsRelOp(oper))
    {
        CTacLabel* next = NULL;
        if (NULL == ltrue && NULL == lfalse)
        {
            ltrue = cb->CreateLabel();
            lfalse = cb->CreateLabel();
            next = cb->CreateLabel();
        }

        if(oper == opAnd)
        {
            CTacLabel* landtrue = cb->CreateLabel();
            CTacAddr* left_addr = _left->ToTac(cb, landtrue, lfalse);
            cb->AddInstr(landtrue);
            CTacAddr* right_addr = _right->ToTac(cb, ltrue, lfalse);
        }
        else if(oper == opOr)
        {
            CTacLabel* lorfalse = cb->CreateLabel();
            CTacAddr* left_addr = _left->ToTac(cb, ltrue, lorfalse);
            cb->AddInstr(lorfalse);
            CTacAddr* right_addr = _right->ToTac(cb, ltrue, lfalse);
        }
        else if (IsRelOp(oper))
        {
            CTacAddr* left_addr = _left->ToTac(cb, ltrue, lfalse);
            CTacAddr* right_addr = _right->ToTac(cb, ltrue, lfalse);
            cb->AddInstr(new CTacInstr(oper, ltrue, left_addr, right_addr));
            cb->AddInstr(new CTacInstr(opGoto, lfalse));
        }
        
        if (NULL != next)
        {
            t = cb->CreateTemp(GetType());
            cb->AddInstr(ltrue);
            cb->AddInstr(new CTacInstr(opAssign, t, new CTacConst(true)));
            cb->AddInstr(new CTacInstr(opGoto, next));
            cb->AddInstr(lfalse);
            cb->AddInstr(new CTacInstr(opAssign, t, new CTacConst(false)));
            cb->AddInstr(new CTacInstr(opGoto, next));
            cb->AddInstr(next);
        }
    }
    else
    {
        CTacAddr* left_addr = _left->ToTac(cb, ltrue, lfalse);
        CTacAddr* right_addr = _right->ToTac(cb, ltrue, lfalse);
        
        t = cb->CreateTemp(GetType());
        cb->AddInstr(new CTacInstr(oper, t, left_addr, right_addr));
    }
    return t;
}

//------------------------------------------------------------------------------
// CAstUnaryOp
//
CAstUnaryOp::CAstUnaryOp(CToken t, EOperation oper, CAstExpression *e)
  : CAstOperation(t, oper), _operand(e)
{
  assert((oper == opNeg) || (oper == opNot) || (oper == opPos));
  assert(e != NULL);
}

CAstExpression* CAstUnaryOp::GetOperand(void) const
{
  return _operand;
}

bool CAstUnaryOp::TypeCheck(CToken *t, string *msg) const
{
    EOperation oper = GetOperation();
    CAstExpression* operand = GetOperand();
    
    if (!operand->TypeCheck(t, msg)) return false;
    if (oper == opNot)
    {
        if(!operand->GetType()->Match(CTypeManager::Get()->GetBool()))
        {
            if (t != NULL) *t = operand->GetToken();
            if (msg != NULL) *msg = "unary operator , operand is not correct type.";
            return false;
        }
    }
    else
    {
        if(!operand->GetType()->Match(CTypeManager::Get()->GetInt()))
        {
            if (t != NULL) *t = operand->GetToken();
            if (msg != NULL) *msg = "unary operator , operand is not correct type.";
            return false;
        }
    }
    return true;
}

const CType* CAstUnaryOp::GetType(void) const
{
    EOperation oper = GetOperation();
    if (oper == opNot)
        return CTypeManager::Get()->GetBool();
    else
        return CTypeManager::Get()->GetInt();
}

ostream& CAstUnaryOp::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << GetOperation() << " ";

  out << endl;

  _operand->print(out, indent+2);

  return out;
}

string CAstUnaryOp::dotAttr(void) const
{
  ostringstream out;
  out << " [label=\"" << GetOperation() << "\",shape=box]";
  return out.str();
}

void CAstUnaryOp::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  _operand->toDot(out, indent);
  out << ind << dotID() << "->" << _operand->dotID() << ";" << endl;
}

//CTacAddr* CAstUnaryOp::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstUnaryOp::ToTac(CCodeBlock *cb, CTacLabel *ltrue, CTacLabel *lfalse)
{
    // generate jumping code for boolean expression
    CTacTemp* t = NULL;
    EOperation oper = GetOperation();
    if (oper == opNot)
    {
        CTacLabel* next = NULL;
        if (NULL == ltrue && NULL == lfalse)
        {
            ltrue = cb->CreateLabel();
            lfalse = cb->CreateLabel();
            next = cb->CreateLabel();
        }
            
        CTacAddr* oper_addr = _operand->ToTac(cb, lfalse, ltrue);
        
        if (NULL != next)
        {
            t = cb->CreateTemp(GetType());
            cb->AddInstr(ltrue);
            cb->AddInstr(new CTacInstr(opAssign, t, new CTacConst(true)));
            cb->AddInstr(new CTacInstr(opGoto, next));
            cb->AddInstr(lfalse);
            cb->AddInstr(new CTacInstr(opAssign, t, new CTacConst(false)));
            cb->AddInstr(new CTacInstr(opGoto, next));
            cb->AddInstr(next);
        }
    }
    else
    {
        CTacAddr* oper_addr = _operand->ToTac(cb, ltrue, lfalse);
        t = cb->CreateTemp(GetType());
        cb->AddInstr(new CTacInstr(oper, t, oper_addr));
    }
    return t;
}

//------------------------------------------------------------------------------
// CAstFunctionCall
//
CAstFunctionCall::CAstFunctionCall(CToken t, const CSymProc *symbol)
  : CAstExpression(t), _symbol(symbol)
{
  assert(symbol != NULL);
}

const CSymProc* CAstFunctionCall::GetSymbol(void) const
{
  return _symbol;
}

void CAstFunctionCall::AddArg(CAstExpression *arg)
{
  _arg.push_back(arg);
}

int CAstFunctionCall::GetNArgs(void) const
{
  return (int)_arg.size();
}

CAstExpression* CAstFunctionCall::GetArg(int index) const
{
  assert((index >= 0) && (index < _arg.size()));
  return _arg[index];
}

bool CAstFunctionCall::TypeCheck(CToken *t, string *msg) const
{
    const CSymProc* proc = GetSymbol();
    int nArgs = GetNArgs();
    int nParams = proc->GetNParams();
    if (nArgs != nParams)
    {
        if (t != NULL) *t = GetToken();
        if (msg != NULL) *msg = "argument counts are different from definition.";
        return false;
    }
    for (int i = 0; i < nArgs; i++)
    {
        CAstExpression* e = GetArg(i);
        if (e == NULL)
        {
            if (t != NULL) *t = GetToken();
            if (msg != NULL) *msg = "invalid argument function call";
            return false;
        }
        else 
        {
            if (!e->TypeCheck(t,msg)) return false;
            const CSymParam* param = proc->GetParam(i);
            if (!e->GetType()->Match(param->GetDataType()))
            {
                if (t != NULL) *t = GetToken();
                if (msg != NULL) *msg = "parameter type mismatch.(now only integer)";
                return false;
            }
        }
    }
    
    return true;
}

const CType* CAstFunctionCall::GetType(void) const
{
  return GetSymbol()->GetDataType();
}

ostream& CAstFunctionCall::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << "call " << _symbol << " ";
  
  out << endl;

  for (size_t i=0; i<_arg.size(); i++) {
    _arg[i]->print(out, indent+2);
  }

  return out;
}

string CAstFunctionCall::dotAttr(void) const
{
  ostringstream out;
  out << " [label=\"call " << _symbol->GetName() << "\",shape=box]";
  return out.str();
}

void CAstFunctionCall::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  for (size_t i=0; i<_arg.size(); i++) {
    _arg[i]->toDot(out, indent);
    out << ind << dotID() << "->" << _arg[i]->dotID() << ";" << endl;
  }
}

//CTacAddr* CAstFunctionCall::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstFunctionCall::ToTac(CCodeBlock *cb, CTacLabel *ltrue, CTacLabel *lfalse)
{
    // generate jumping code for boolean expression
    CTacTemp* t = NULL;
    int nArgs = GetNArgs();
    const CType* type = GetType();
    for ( int nIndex = nArgs - 1 ; nIndex >= 0 ; nIndex--)
    {
        CTacAddr* arg = GetArg(nIndex)->ToTac(cb, NULL, NULL);
        cb->AddInstr(new CTacInstr(opParam, new CTacConst(nIndex), arg));
    }

    if (!type->Match(CTypeManager::Get()->GetNull()))
        t = cb->CreateTemp(type);
    cb->AddInstr(new CTacInstr(opCall, t, new CTacName(GetSymbol())));
    
    if (type->Match(CTypeManager::Get()->GetBool()) && NULL != ltrue && NULL != lfalse)
    {
        cb->AddInstr(new CTacInstr(opEqual, ltrue, t, new CTacConst(true)));
        cb->AddInstr(new CTacInstr(opGoto, lfalse));
    }
    return t;
}

//------------------------------------------------------------------------------
// CAstOperand
//
CAstOperand::CAstOperand(CToken t)
  : CAstExpression(t)
{
}


//------------------------------------------------------------------------------
// CAstDesignator
//
CAstDesignator::CAstDesignator(CToken t, const CSymbol *symbol,
                               CAstExpression *offset)
  : CAstOperand(t), _symbol(symbol), _offset(offset)
{
  assert(symbol != NULL);
}

const CSymbol* CAstDesignator::GetSymbol(void) const
{
  return _symbol;
}

bool CAstDesignator::TypeCheck(CToken *t, string *msg) const
{
    if (GetType()->Match(CTypeManager::Get()->GetNull()))
    {
        if (t != NULL) *t = GetToken();
        if (msg != NULL) *msg = "Designator is NULL Type.";
        return false;
    }
    return true;
}

const CType* CAstDesignator::GetType(void) const
{
  const CType *t = GetSymbol()->GetDataType();

  if (_offset != NULL) {
    if (t->IsArray() && (_offset->GetType()->IsScalar())) {
      const CArrayType *at = dynamic_cast<const CArrayType*>(t);
      assert(at != NULL);
      t = at->GetBaseType();
    } else {
      t = NULL;
    }
  }

  return t;
}

ostream& CAstDesignator::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << _symbol << " ";

  out << endl;

  if (_offset != NULL) _offset->print(out, indent+2);

  return out;
}

string CAstDesignator::dotAttr(void) const
{
  ostringstream out;
  out << " [label=\"" << _symbol->GetName();
  if (_offset != NULL) out << "[]";
  out << "\",shape=ellipse]";
  return out.str();
}

void CAstDesignator::toDot(ostream &out, int indent) const
{
  string ind(indent, ' ');

  CAstNode::toDot(out, indent);

  if (_offset != NULL) {
    _offset->toDot(out, indent);
    out << ind << dotID() << "->" << _offset->dotID() << ";" << endl;
  }
}

//CTacAddr* CAstDesignator::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstDesignator::ToTac(CCodeBlock *cb, CTacLabel *ltrue, CTacLabel *lfalse)
{
    // generate jumping code for boolean expression
    CTacAddr* val = new CTacName(_symbol);
    if (GetType()->Match(CTypeManager::Get()->GetBool()))
    {
        if (NULL != ltrue && NULL != lfalse)
        {
            cb->AddInstr(new CTacInstr(opEqual, ltrue, val, new CTacConst(true)));
            cb->AddInstr(new CTacInstr(opGoto, lfalse));
        }
    }
    return val;
}


//------------------------------------------------------------------------------
//4CAstConstant
//
CAstConstant::CAstConstant(CToken t, const CType *type, long long value)
  : CAstOperand(t), _type(type), _value(value)
{
}

void CAstConstant::SetValue(long long value)
{
  _value = value;
}

long long CAstConstant::GetValue(void) const
{
  return _value;
}

string CAstConstant::GetValueStr(void) const
{
  ostringstream out;

  if (GetType() == CTypeManager::Get()->GetBool()) {
    out << (_value == 0 ? "false" : "true");
  } else {
    out << dec << _value;
  }

  return out.str();
}

bool CAstConstant::TypeCheck(CToken *t, string *msg) const
{
    const CType* type = GetType();
    if (type->Match(CTypeManager::Get()->GetNull()))
    {
        if (t != NULL) *t = GetToken();
        if (msg != NULL) *msg = "Constant is NULL type.";
        return false;
    }
    else if (type->Match(CTypeManager::Get()->GetInt()))
    {
        //[Check] Range check
        long long value = GetValue();
        if ((value > 2147483647) || (value < -2147483648))
        {
            if (t != NULL) *t = GetToken();
            if (msg != NULL) *msg = "Constant integer is out of range.";
            return false;
        }
    }
    return true;
}

const CType* CAstConstant::GetType(void) const
{
  return _type;
}

ostream& CAstConstant::print(ostream &out, int indent) const
{
  string ind(indent, ' ');

  out << ind << GetValueStr() << " ";

  out << endl;

  return out;
}

string CAstConstant::dotAttr(void) const
{
  ostringstream out;
  out << " [label=\"" << GetValueStr() << "\",shape=ellipse]";
  return out.str();
}

//CTacAddr* CAstConstant::ToTac(CCodeBlock *cb)
//{
//  return NULL;
//}

CTacAddr* CAstConstant::ToTac(CCodeBlock *cb, CTacLabel *ltrue, CTacLabel *lfalse)
{
    // generate jumping code for boolean expression
    if (GetType()->Match(CTypeManager::Get()->GetBool()))
    {
        if (NULL != ltrue && NULL != lfalse)
        {
            if (0 == _value)
                cb->AddInstr(new CTacInstr(opGoto, lfalse));
            else
                cb->AddInstr(new CTacInstr(opGoto, ltrue));
        }
    }

    return new CTacConst(_value);
}

